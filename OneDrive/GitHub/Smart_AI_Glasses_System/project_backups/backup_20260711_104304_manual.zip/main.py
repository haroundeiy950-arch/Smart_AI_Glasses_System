from settings import create_project_folders
from ui import SmartGlassesUI


def main() -> None:
    create_project_folders()
    app = SmartGlassesUI()
    app.run()



if __name__ == "__main__":
    main()
